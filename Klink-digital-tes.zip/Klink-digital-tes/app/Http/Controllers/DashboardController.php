<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        $data = [
            'title' => 'Dashboard',
            'user' => 'Michael',
            'totalUsers' => 120,
            'totalPosts' => 45
        ];

        return view('dashboard', $data);
    }
}