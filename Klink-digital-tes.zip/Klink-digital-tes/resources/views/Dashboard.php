<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>{{ $title }}</title>

    <!-- Tailwind CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">

    <!-- Navbar -->
    <div class="bg-white shadow p-4 flex justify-between">
        <h1 class="text-xl font-bold">Dashboard</h1>
        <a href="/items" class="bg-blue-500 text-white px-4 py-2 rounded-lg">
            List Item
        </a>
    </div>

    
        <h2 class="text-2xl font-semibold mb-4">
            Halo, {{ $user }} 👋
        </h2>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            
            <div class="bg-white p-4 rounded-2xl shadow">
                <h3 class="text-lg font-semibold">Total Users</h3>
                <p class="text-3xl text-blue-500 mt-2">
                    {{ $totalUsers }}
                </p>
            </div>
            
            <div class="bg-white p-4 rounded-2xl shadow">
                <h3 class="text-lg font-semibold">Total Posts</h3>
                <p class="text-3xl text-green-500 mt-2">
                    {{ $totalPosts }}
                </p>
            </div>

        </div>
    </div>

</body>
</html>